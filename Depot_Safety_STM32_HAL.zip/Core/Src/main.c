/* USER CODE BEGIN Header */
/*
 * Depot Safety Monitoring System
 * Target: NUCLEO-F446RE
 * Framework: STM32Cube HAL
 *
 * CubeMX configuration required:
 *   USART2: PA2 TX, PA3 RX, 115200 baud, 8-N-1
 *   PA0: digital vibration sensor input, pull-down
 *   PA1: DHT11 data (dynamically switched by software)
 *   PA5: alert LED output
 *   PB0: active buzzer output
 *
 * Note: USART2 carries CSV records only. Use SWV/ITM or another UART
 * for separate human-readable debug output.
 */
/* USER CODE END Header */

#include "main.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* CubeMX-generated handle */
extern UART_HandleTypeDef huart2;

/* Pin mapping */
#define DHT_PORT       GPIOA
#define DHT_PIN        GPIO_PIN_1
#define VIB_PORT       GPIOA
#define VIB_PIN        GPIO_PIN_0
#define LED_PORT       GPIOA
#define LED_PIN        GPIO_PIN_5
#define BUZZER_PORT    GPIOB
#define BUZZER_PIN     GPIO_PIN_0

#define MAX_TEMP       45.0f
#define MAX_HUMIDITY   85.0f
#define SHAKE_TIME     10000UL
#define SENSOR_TIME    2000UL

static float temperature = 0.0f;
static float humidity = 0.0f;

static uint32_t lastSensorRead = 0;
static uint32_t lastShakeTime = 0;
static uint32_t shakeCount = 0;
static uint32_t firstShake = 0;
static int shakeNumber = 0;

static uint8_t oldVibration = 0;
static uint8_t vibration = 0;
static uint8_t prediction = 0;

/* DWT cycle counter for approximate microsecond delays */
static void DWT_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

static void delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (HAL_RCC_GetHCLKFreq() / 1000000U);
    while ((uint32_t)(DWT->CYCCNT - start) < ticks) {
        /* wait */
    }
}

static void DHT_SetOutput(void)
{
    GPIO_InitTypeDef gpio = {0};
    gpio.Pin = DHT_PIN;
    gpio.Mode = GPIO_MODE_OUTPUT_OD;
    gpio.Pull = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DHT_PORT, &gpio);
}

static void DHT_SetInput(void)
{
    GPIO_InitTypeDef gpio = {0};
    gpio.Pin = DHT_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(DHT_PORT, &gpio);
}

/* Returns 1 on a valid DHT11 frame, 0 on timeout/checksum failure. */
static uint8_t DHT_Read(float *temp, float *hum)
{
    uint8_t data[5] = {0};
    uint32_t timeout;

    DHT_SetOutput();
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_RESET);
    HAL_Delay(20);
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_SET);
    delay_us(30);
    DHT_SetInput();

    timeout = 0;
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET) {
        if (++timeout > 10000U) return 0;
        delay_us(1);
    }

    timeout = 0;
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_RESET) {
        if (++timeout > 10000U) return 0;
        delay_us(1);
    }

    timeout = 0;
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET) {
        if (++timeout > 10000U) return 0;
        delay_us(1);
    }

    for (int i = 0; i < 40; i++) {
        timeout = 0;
        while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_RESET) {
            if (++timeout > 10000U) return 0;
            delay_us(1);
        }

        delay_us(40);
        if (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET) {
            data[i / 8] |= (uint8_t)(1U << (7 - (i % 8)));
        }

        timeout = 0;
        while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET) {
            if (++timeout > 10000U) return 0;
            delay_us(1);
        }
    }

    if ((uint8_t)(data[0] + data[1] + data[2] + data[3]) != data[4]) {
        return 0;
    }

    *hum = (float)data[0];
    *temp = (float)data[2];
    return 1;
}

static void Safety_Task(void)
{
    uint32_t now = HAL_GetTick();
    uint8_t sensorState =
        (HAL_GPIO_ReadPin(VIB_PORT, VIB_PIN) == GPIO_PIN_SET) ? 1U : 0U;

    /* Count each low-to-high vibration transition. */
    if (sensorState && !oldVibration) {
        shakeCount++;
        shakeNumber++;
        if (shakeNumber == 1) {
            firstShake = now;
        }
    }
    oldVibration = sensorState;

    if (sensorState) {
        lastShakeTime = now;
    }

    vibration = (sensorState ||
                (lastShakeTime != 0U && (now - lastShakeTime) < 1000U)) ? 1U : 0U;

    prediction = 0U;
    if (shakeNumber >= 2) {
        if ((now - firstShake) <= SHAKE_TIME) {
            prediction = 1U;
        } else {
            shakeNumber = 1;
            firstShake = now;
        }
    }

    if ((now - lastSensorRead) >= SENSOR_TIME) {
        lastSensorRead = now;
        float t, h;
        if (DHT_Read(&t, &h)) {
            temperature = t;
            humidity = h;
        }
    }

    uint8_t temperatureAlert = (temperature >= MAX_TEMP) ? 1U : 0U;
    uint8_t humidityAlert = (humidity >= MAX_HUMIDITY) ? 1U : 0U;
    uint8_t alarm = (vibration || temperatureAlert || humidityAlert || prediction) ? 1U : 0U;

    HAL_GPIO_WritePin(LED_PORT, LED_PIN, alarm ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, alarm ? GPIO_PIN_SET : GPIO_PIN_RESET);

    /* CSV format: temperature,humidity,vibration,alarm,shakeCount,prediction */
    char tx[100];
    int len = snprintf(tx, sizeof(tx), "%.1f,%.1f,%u,%u,%lu,%u\r\n",
                       temperature, humidity, vibration, alarm,
                       (unsigned long)shakeCount, prediction);
    if (len > 0 && len < (int)sizeof(tx)) {
        (void)HAL_UART_Transmit(&huart2, (uint8_t *)tx, (uint16_t)len, 100);
    }

    HAL_Delay(50);
}

/* Keep CubeMX-generated SystemClock_Config, MX_GPIO_Init and
 * MX_USART2_UART_Init functions in the project. */
int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART2_UART_Init();

    DWT_Init();

    const char startMsg[] = "Depot Safety Monitoring System Started\r\n";
    (void)HAL_UART_Transmit(&huart2, (uint8_t *)startMsg,
                           (uint16_t)(sizeof(startMsg) - 1U), 100);

    while (1) {
        Safety_Task();
    }
}
