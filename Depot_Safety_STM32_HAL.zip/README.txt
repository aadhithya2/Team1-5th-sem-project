# Depot Safety Monitoring System — STM32 HAL source package

Target board: **NUCLEO-F446RE**
IDE: **STM32CubeIDE**
HAL: STM32F4 HAL

## Important
This is an application source package, not a complete standalone STM32CubeIDE project.
CubeIDE must generate the startup code, linker script, HAL drivers, clock setup, and peripheral initialization for your installed STM32CubeF4 firmware package.

## Pin mapping

| Device | STM32 pin | CubeMX mode |
|---|---|---|
| DHT11 DATA | PA1 | GPIO (software switches input/output) |
| Digital vibration sensor OUT | PA0 | GPIO input, pull-down |
| Alert LED | PA5 | GPIO output |
| Active buzzer signal | PB0 | GPIO output |
| UART TX | PA2 | USART2_TX |
| UART RX | PA3 | USART2_RX |
| Sensor supply | 3.3 V or module-rated supply | Check module specifications |
| Ground | GND | Common ground |

DHT11 DATA should have a 4.7–10 kΩ pull-up to 3.3 V. Do not pull the STM32 input to 5 V.

## Setup in STM32CubeIDE

1. Create a new STM32 project for **NUCLEO-F446RE**.
2. In the `.ioc` pinout, configure PA0 as GPIO input with pull-down.
3. Configure PA1 as GPIO output initially. The program changes it dynamically to input while reading DHT11.
4. Configure PA5 and PB0 as GPIO outputs.
5. Enable USART2 in Asynchronous mode, set 115200 baud, 8 data bits, no parity, 1 stop bit.
6. Generate code.
7. Replace the generated `Core/Src/main.c` with the supplied `Core/Src/main.c`, or carefully merge its code into your generated file.
8. Keep your CubeMX-generated `SystemClock_Config()`, `MX_GPIO_Init()`, and `MX_USART2_UART_Init()` functions.
9. Build, connect the board by USB, and click Run/Debug.
10. Open a serial terminal for the ST-LINK VCP at 115200 baud.

## UART output
CSV format:
`temperature,humidity,vibration,alarm,shakeCount,prediction`

Example:
`29.0,60.0,0,0,0,0`

## Notes
- This source uses a **digital vibration sensor**, matching the provided Arduino code. It does not use an MPU6050.
- If the sensor's output is active LOW, change the vibration input logic in `Safety_Task()`.
- The DHT11 bit-banged driver depends on accurate timing. If readings fail, check the pull-up, wiring, sensor module type, and clock frequency.
- A buzzer that draws more current than a GPIO can safely supply needs a transistor driver.
- Threshold logic is a demonstration only, not a validated hazard prediction system.
- The generated CubeIDE project must include the HAL drivers and startup/linker files. This package alone cannot be imported as a complete project.
